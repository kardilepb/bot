var util = require('util');
var rp = require('request-promise');
var LuisActions = require('../core');

var afterShipAPI = require('aftership')('cee5b27d-cfd3-4885-8e87-c3f5916f705f');

var ApixuApiKey = process.env.APIXU_API_KEY;

var TrackOrderAction = {
    intentName: 'Track Order',
    friendlyName: 'Where is my order?',
    //canExecuteWithoutContext: false,
    confirmOnContextSwitch: false,
    // Property validation based on schema-inspector
    schema: {
    },
    // Action fulfillment method, recieves parameters as keyed-object (parameters argument) and a callback function to invoke with the fulfillment result.
    fulfill: function (parameters, callback) {        
        //callback(parameters.optionChoosed);    
        console.log(parameters);  
        //LuisActions.evaluate();  
        callback("Track your order by choosing below options:\n <br/>1. Delivery ID \n <br/>2. Order number & Part number");
        // callback(util.format("Your order is shipped by FEDEX courier service with tracking number 789352726616 and current status is 'Delivered'") +" "+JSON.stringify(parameters));
		/*rp({
            url: util.format('http://api.apixu.com/v1/current.json?key=%s&q=%s', ApixuApiKey, encodeURIComponent(parameters.Place)),
            json: true
        }).then(function (data) {
            if (data.error) {
                callback(data.error.message + ': "' + parameters.Place + '"');
            } else {
                callback(util.format('The current weather in %s, %s is %s (humidity %s %%)',
                    data.location.name, data.location.country, data.current.condition.text, data.current.humidity));
            }
        }).catch(console.error);*/
    }
};

// Contextual action that changes delivery id for the TrackOrderAction
var TrackOrderAction_ByDeliveyId = {
    intentName: 'Track Order By Delivery ID',
    friendlyName: 'Change Delivery Id for order',
    //parentAction: TrackOrderAction,
    canExecuteWithoutContext: false,
    schema: {
        DeliveyID: {
            type: 'string',
            //builtInType: LuisActions.BuiltInTypes.DateTime.Date,
            message: 'Please provide delivery id...'
        }
    },
    fulfill: function (parameters, callback) {
        //parentContextParameters.DeliveyID = parameters.DeliveyID;
       // callback('Delivery Id changed to ' + parameters.DeliveyID);
        var options = {
            method: 'POST',
            uri: 'https://ps1w2.rt.informaticacloud.com/active-bpel/rt/ZEBChatBotToERPProcess',
            body: {
                "INTENT":"Retrieve Tracking",
                "OPERATING_UNIT":"ZTI OU",
                "DELIVERY_ID":""+parameters.DeliveyID+""
                //"DELIVERY_ID":"12467117"
            },
            headers: {
                //'User-Agent': 'Request-Promise'
                "authorization": "Basic aW5mYWludGZ1c2VyQHplYnJhLmNvbS5kZXY6emVicmExMjM=",
                "Content-Type": "application/json",
                "cache-control": "no-cache"
            },
            json: true // Automatically stringifies the body to JSON
        };
        rp(options)
         .then(function (repos) {
            try{
    	            var items = repos.OutputParameters.P_OUTPUT_TBL.P_INPUT_TBL_ITEM;
                    var trackingDetails ={};
                   // session.privateConversationData.trackingDetails = {};
    	            var validItems = [];
                    var outStr = "";
    	            for(var item in items){
    	                if(items.hasOwnProperty(item)){
    	                    var it = {};
    	                    it.carrier = items[item].C_ARGUMENT1;
    	                    it.trackingId = items[item].C_ARGUMENT2;
    	                    validItems.push(it);
                            trackingDetails[it.trackingId] ={};
                            //session.privateConversationData.trackingDetails[it.trackingId] = {};
                            outStr +=" \nCarrier: "+it.carrier+" Tracking Id: "+it.trackingId;
    	                }
    	            } 
                    var totalItemCount =0;
                    totalItemCount = validItems.length; ;
                    //var counter = 0;  
                   // callback.privateConversationData.totalItemCount = validItems.length;      
                    //callback.privateConversationData.counter = 0;     
                    console.log("Count: "+totalItemCount); 
                    //console.log("Counter: "+counter);          
    	           //session.send('For the given delivery id, we have below tracking details:'+outStr+' \nWe are retrieving details of these tracking ids, please wait...');
                   // session.endDialog();
                   if(validItems.length >0){
                    for(var itm in validItems){
                       if(validItems.hasOwnProperty(itm)){
                            getTrackingDetails(callback,validItems[itm], totalItemCount, trackingDetails);
                       }
                    }
                   } else{
                       callback("We are unable to retrieve tracking details for given delivery id, please try after sometime.");
                   }
                    //callback(outStr);
                }catch(error){
                    console.log(error);
                    callback("We are unable to retrieve tracking details for given delivery id, please try after sometime.");
                    //session.endDialog("We are unable to retrieve tracking details for given delivery id, please try after sometime."); 
                }
        })
        .catch(function (err) {
            // API call failed...
            console.log(err);
            callback("We are unable to retrieve tracking details for given delivery id, please try after sometime. err");
        });
    }
};

// Contextual action that changes order number and part number for the TrackOrderAction
var TrackOrderAction_ByOrderNumber = {
    intentName: 'Track Order by Order Number',
    friendlyName: 'Change the order number or track number',
    //parentAction: TrackOrderAction,
    canExecuteWithoutContext: false,
    schema: {
         OrderNumber: {
            type: 'string',
            //builtInType: LuisActions.BuiltInTypes.Geography.City,
            message: 'Please provide order number'
        },
        PartNumber: {
            type: 'string',
            //builtInType: LuisActions.BuiltInTypes.Geography.City,
            message: 'Please provide part number'
           // optional: true
        }
    },
    fulfill: function (parameters, callback) {
        //parentContextParameters.OrderNumber = parameters.OrderNumber;
        callback('Order number changed to ' + parameters.OrderNumber);
    }
};


function getTrackingDetails(callback, item, totalItemCount, trackingDetails){    
    var slug = item.carrier;
    if(slug){
       slug = slug.toLowerCase();   
    }
    var body = {
        'tracking': {
            'slug': slug,
            'tracking_number': item.trackingId,
            'title': 'Track:'+slug+":"+item.trackingId
        }
    };
    afterShipAPI.call('POST', '/trackings/',{ body: body}).then(function (result) {
    	//console.log(result);
        //session.endDialog(JSON.stringify(result));
        getTrackingStatus(callback, result.data.tracking.id, totalItemCount, trackingDetails);
    }).catch(function (err) {
       // console.log(err);
        if(err.code == "4003"){
            getTrackingStatus(callback, err.data.tracking.id, totalItemCount, trackingDetails);
        }else{
            console.log(err);
            callback("We are unable to retrieve tracking details, please try after some time.");
        }
    });
}
//var count =0;
function getTrackingStatus(callback, id, totalItemCount, trackingDetails){
    if(id){
        this.counter = this.counter || 0;
        var _this = this;
        afterShipAPI.call('GET', '/trackings/'+id).then(function (result) {
        	//console.log(result);
            try{
                
                console.log(JSON.stringify(result));
                console.log("Count: "+totalItemCount+ "Counter: "+_this.counter);
                var checkPointLen = result.data.tracking.checkpoints.length;
    			var checkPointDetails = {};
    			if(checkPointLen > 0){
    				checkPointDetails = result.data.tracking.checkpoints[checkPointLen-1];
    			}else{
    				checkPointDetails.tag = result.data.tracking.tag;
    			}                
                
                if(totalItemCount ==1){
                    var outString = "Current status of traking id of your order is as below: \nTracking ID: "+result.data.tracking.tracking_number+" Carrier: "+result.data.tracking.slug+" Status: "+checkPointDetails.tag+((checkPointDetails.tag !== 'Delivered' && checkPointDetails.tag !== 'Pending')? " Message: "+checkPointDetails.message: "");
                    callback(outString);                   
                } else{
                    _this.counter++;
                     
                    trackingDetails[result.data.tracking.tracking_number].slug = result.data.tracking.slug;
                    trackingDetails[result.data.tracking.tracking_number].tag = checkPointDetails.tag;
                    trackingDetails[result.data.tracking.tracking_number].message = checkPointDetails.message;
                    
                    if(totalItemCount ==  _this.counter){
                        var resString = "Current status of traking ids in your order is as below:";
                        //resString +="\n<table><tr><th>Tracking ID<\th><th>Carrier</th><th>Status</th></tr>";
                        var trackings = trackingDetails;
                        for(var track in trackings){
                            if(trackings.hasOwnProperty(track)){
                                resString += " \nTracking ID: "+track+" Carrier: "+trackings[track].slug+" Status: "+trackings[track].tag+((trackings[track].tag !== 'Delivered' && trackings[track].tag !== 'Pending')? " Message: "+trackings[track].message: "");
                               // resString += " <tr><td> "+track+" </td><td> "+trackings[track].slug+" </td><td> "+trackings[track].tag+((trackings[track].tag !== 'Delivered' && trackings[track].tag !== 'Pending')? " Message: "+trackings[track].message: "")+"</td></tr>";
                            }
                        }
                       // resString +="</table>";
                         _this.counter = 0;
                        callback(resString);
                        
                    }
                }
            }catch(error){
                console.log(error);
                callback("We are unable to retrieve tracking details, please try after some time.");
            }
        }).catch(function (err) {
        	console.log(err);
            callback("We are unable to retrieve tracking details, please try after some time.");
        });
    }
}

module.exports = [TrackOrderAction, TrackOrderAction_ByDeliveyId, TrackOrderAction_ByOrderNumber];