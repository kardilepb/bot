// export samples
module.exports = []
   .concat(require('./intents/trackorder'))
   .concat(require('./intents/product'))
   .concat(require('./intents/weather'));
    
    //.concat(require('./airports'));